import React from 'react';

const FormItem = ({children}) => {
  return <div className="formItem">{children}</div>;
};

export default FormItem;
